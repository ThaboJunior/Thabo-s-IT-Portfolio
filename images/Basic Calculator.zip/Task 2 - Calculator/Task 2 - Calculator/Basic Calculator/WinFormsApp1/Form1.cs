namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //declarations
            int value1;
            int value2;
            int answer;

            value1 = Convert.ToInt32(textBox1.Text);
            value2 = Convert.ToInt32(textBox2.Text);

            //Calculation
            answer = value1 + value2;

            label3.Text = "The sum of " + value1 + " And " + value2 + " Is: " + answer;


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            //declarations
            int value1;
            int value2;
            int answer1;

            value1 = Convert.ToInt32(textBox1.Text);
            value2 = Convert.ToInt32(textBox2.Text);

            //Calculation
            answer1 = value1 - value2;

            label3.Text = value1 + " Minus " + value2 + " Is: " + answer1;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //declarations
            int value1;
            int value2;
            int answer2;

            value1 = Convert.ToInt32(textBox1.Text);
            value2 = Convert.ToInt32(textBox2.Text);

            //Calculation
            answer2 = value1 * value2;

            label3.Text = value1 + " Multiplied by " + value2 + " Is: " + answer2;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //declarations
            int value1;
            int value2;
            int answer3;

            value1 = Convert.ToInt32(textBox1.Text);
            value2 = Convert.ToInt32(textBox2.Text);

            //Calculation
            answer3 = value1 / value2;

            label3.Text = value1 + " divided by " + value2 + " Is: " + answer3;
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {

        }

       
        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}